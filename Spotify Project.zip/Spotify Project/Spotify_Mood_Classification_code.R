library('spotifyr')
library('ggplot2')
library('tidyverse')
library('knitr')
library('tidyverse')  # data manipulation
library('cluster')    # clustering algorithms
library('factoextra') # clustering algorithms & visualization

# Set working directory to source file location
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# Setup Spotify API credentials
Sys.setenv(SPOTIFY_CLIENT_ID = '6626923a39fa4eba91b4571f862468b9')
Sys.setenv(SPOTIFY_CLIENT_SECRET = 'e1c0dd2a1be94eeeb9afc896b53b4545')
access_token <- get_spotify_access_token()


# Download the names of MTV's top 10000 artists
link = 'https://gist.github.com/mbejda/9912f7a366c62c1f296c/raw/dd94a25492b3062f4ca0dc2bb2cdf23fec0896ea/10000-MTV-Music-Artists-page-1.csv'
curr_path = getwd()
curr_path_filename = paste(curr_path,'/artists_alldata.csv',sep='')

download.file(link, curr_path_filename)
artists_alldata <- read.csv(file=curr_path_filename, header=TRUE, sep=",")


# Extract only artist names and delete extraneous data
artist_names = artists_alldata[c('name')]

rm(artists_alldata)


# Get spotify audio features for each artist in 'artist_names' until we get features for
# over 20,000 songs
df = data.frame(matrix(ncol=13,nrow=0))

curr_iter = 1
while (nrow(df) < 20001){
  try({
    curr_artist_info = get_artist_audio_features(as.character(artist_names[curr_iter,'name']))
    df = rbind(df,curr_artist_info[,c('artist_name','track_name',
                                   'acousticness','danceability',
                                   'liveness','loudness',
                                   'speechiness')])
    print(as.character(artist_names[curr_iter,'name']))
  })
  curr_iter = curr_iter + 1
  print(curr_iter)
}


# Save Spotify API data to a .csv file; then manually upload file to github
write.csv(df, file = "df_SpotifyData.csv")


##############################################################################################
##############################################################################################
##############################################################################################
##############################################################################################
##############################################################################################
##############################################################################################
##############################################################################################


# Import Spotify API data from current path
df <- read.csv("df_SpotifyData.csv")


# Create column names (to facilitate extracting specific columns from dataframe) 
# for Artists & Tracks and for Variables Used (for Clustering and for ML)
var_name = c('artist_name','track_name')
var_name_norm = c('acousticness','danceability','liveness','loudness','speechiness')


# Create function which normalizes data so that variables are from 0 to 1
normalized<-function(y) {
  x<-y[!is.na(y)]
  x<-(x - min(x)) / (max(x) - min(x))
  y[!is.na(y)]<-x
  
  return(y)
}


# Normalize variables so that they range from 0 to 1
dfNorm = data.frame(matrix(ncol=0,nrow=nrow(df)))

for (i in var_name_norm) {
  dfNorm = data.frame(dfNorm[,],normalized(df[,i]))
}

dfNorm = apply(df[,var_name_norm],2,normalized)



##############################################################################################
##############################################################################################
##############################################################################################
###########################Find optimal number of clusters####################################
##############################################################################################
##############################################################################################
##############################################################################################

# Visualize subset of data using a Distance Matrix
df_plot = dfNorm[1:50,var_name_norm]
row.names(df_plot) = df[1:50,c('track_name')]
 
distance <- get_dist(df_plot)
fviz_dist(distance, gradient = list(low = "#00AFBB", mid = "white", high = "#FC4E07"))


# K-means Elbow Method - Results indicate optimal number of clusters = 5
fviz_nbclust(dfNorm,kmeans,method='wss')


# K-means Silhouette Method - Results indicate optimal number of clusters = 2
fviz_nbclust(dfNorm,kmeans,method='silhouette')


# Finalize the number of clusters based on Elbow, Silhouette and Gap Statistic results
# Optimal number of clusters chosen is: 5. Although two methods above have conflicting
# results, we choose 5 clusters because it seems unreasonable to believe that the dataset
# contains only 2 different types of music.
set.seed(123)
final <- kmeans(dfNorm, 5, nstart = 25)
print(final)


# Visualize clusters by plotting 2 most dominant dimensions
# for Principal Component data (dimensionality reduction)
# It can be seen that there is significant overlap between clusters;
# however, we can also see that the first two dimensions of the 
# dimentionality reduction data only accounts for ~60 percent of
# the variability seen in the original data. This plot is only used 
# for visualization purposes. Therefore, we believe that this is not
# an ideal classification of the data, but other cluster numbers
# proved to not result in significant improvements.
fviz_cluster(final, data = dfNorm)


# Add cluster labels to original dataset
df_NormCluster = data.frame(df[,var_name],dfNorm,final$cluster)

colnames(df_NormCluster) = var_name = c('artist_name','track_name',
                                        'acousticness','danceability',
                                        'liveness','loudness','speechiness',
                                        'cluster_num')


# Display subset of songs for each cluster

sample_n(df_NormCluster[df_NormCluster$cluster_num == 1,],10)
sample_n(df_NormCluster[df_NormCluster$cluster_num == 2,],10)
sample_n(df_NormCluster[df_NormCluster$cluster_num == 3,],10)
sample_n(df_NormCluster[df_NormCluster$cluster_num == 4,],10)
sample_n(df_NormCluster[df_NormCluster$cluster_num == 5,],10)



write.csv(df_NormCluster, file = "df_SpotifyData_wlabels.csv")



################################
library(caret)
library(caTools)
set.seed(123)
split = sample.split(df_NormCluster$cluster_num,SplitRatio = 0.75)
training_set=subset(df_NormCluster,split==TRUE)
test_set=subset(df_NormCluster,split==FALSE)


library(e1071)
classifier = svm(formula = cluster_num ~acousticness+danceability+liveness+loudness+speechiness, data = training_set, type = 'C-classification',kernel='linear')
y_pred = predict(classifier,newdata = test_set[-8])
cm = table(test_set[,8],y_pred,dnn=c("Prediction", "Actual"))
cm


n = sum(cm) # number of instances
nc = nrow(cm) # number of classes
diag = diag(cm) # number of correctly classified instances per class 
rowsums = apply(cm, 1, sum) # number of instances per class
colsums = apply(cm, 2, sum) # number of predictions per class
p = rowsums / n # distribution of instances over the actual classes
q = colsums / n # distribution of instances over the predicted classes

accuracy = sum(diag) / n
accuracy
precision = diag / colsums 
recall = diag / rowsums 
f1 = 2 * precision * recall / (precision + recall) 
data.frame(precision, recall, f1)

macroPrecision = mean(precision)
macroRecall = mean(recall)
macroF1 = mean(f1)
data.frame(macroPrecision, macroRecall, macroF1)



##2nd model


library(randomForest)

classifier_rf= randomForest(formula = cluster_num ~acousticness+danceability+liveness+loudness+speechiness, data = training_set, importance = TRUE)
classifier_rf
y_pred = predict(classifier_rf,newdata = test_set[-8])
cm_rf = table(test_set[,8],y_pred,dnn=c("Prediction", "Actual"))
cm_rf


n = sum(cm_rf) # number of instances
nc = nrow(cm_rf) # number of classes
diag = diag(cm_rf) # number of correctly classified instances per class 
rowsums = apply(cm_rf, 1, sum) # number of instances per class
colsums = apply(cm_rf, 2, sum) # number of predictions per class
p = rowsums / n # distribution of instances over the actual classes
q = colsums / n # distribution of instances over the predicted classes

accuracy = sum(diag) / n
accuracy
precision = diag / colsums 
recall = diag / rowsums 
f1 = 2 * precision * recall / (precision + recall) 

macroPrecision = mean(precision)
macroRecall = mean(recall)
macroF1 = mean(f1)
data.frame(macroPrecision, macroRecall, macroF1)
